# EV Monitoring and ADAS Demo — STM32F103C8T6 (Blue Pill)

> **Important:** This is a bench-top educational starter project, not a road-ready vehicle controller. It does not control a motor, brakes, steering, battery contactors, or any safety-critical vehicle function. Test with low-voltage lab supplies only.

## What this starter demonstrates

- Battery-voltage measurement using the STM32 ADC and an external resistor divider.
- Distance measurement using an HC-SR04 ultrasonic sensor.
- Simple proximity warning using an LED and buzzer.
- UART debug output (optional).

These are example modules. They are not evidence that these features were present in your original project. Change the hardware mapping and thresholds to match your actual build.

## Hardware

- STM32F103C8T6 Blue Pill (3.3 V GPIO)
- HC-SR04 ultrasonic sensor
- LED with a suitable series resistor
- Active buzzer driven through a transistor/MOSFET driver
- Battery-voltage sensing resistor divider, sized for the maximum input voltage
- Regulated supply, common ground, jumper wires

### Example pin mapping

| Function | Blue Pill pin | MCU peripheral |
|---|---|---|
| Battery divider output | PA0 | ADC1_IN0 |
| HC-SR04 TRIG | PB0 | GPIO output |
| HC-SR04 ECHO | PB1 | GPIO input, **3.3 V max** |
| Warning LED | PC13 | GPIO output (board LED may be active-low) |
| Buzzer driver input | PB12 | GPIO output |
| UART TX/RX (optional) | PA9 / PA10 | USART1 |

**Voltage safety:** Never connect a battery directly to PA0. Use a correctly calculated divider and ensure PA0 remains within 0–3.3 V. Many HC-SR04 modules output 5 V on ECHO; use a resistor divider or level shifter before PB1. Drive a buzzer through a suitable transistor driver, not directly from an MCU pin.

## Software setup

1. Install STM32CubeIDE.
2. Create a new STM32 project for `STM32F103C8Tx` / Blue Pill.
3. In CubeMX, configure:
   - ADC1 channel 0 (PA0), 12-bit, software trigger.
   - PB0 as GPIO output (TRIG).
   - PB1 as GPIO input (ECHO).
   - PC13 as GPIO output (LED).
   - PB12 as GPIO output (buzzer driver).
   - USART1 at 115200 baud if using serial debug.
4. Add `Core/Inc/*.h` and `Core/Src/*.c` from this package to your CubeIDE project.
5. Use the `main.c` integration example as a guide, then merge it with the CubeMX-generated `main.c`. Keep the generated clock and peripheral initialization functions.
6. Build and flash using an ST-Link or supported programmer.

## Configuration

Open `Core/Inc/app_config.h` and adjust:
- `BATTERY_DIVIDER_RATIO` to match your resistor divider.
- `BATTERY_WARN_VOLTAGE` to suit your bench supply / battery chemistry.
- `ADAS_WARN_DISTANCE_CM` to set the proximity warning distance.

The divider ratio is `(R_TOP + R_BOTTOM) / R_BOTTOM`. Example: 30 kΩ top and 10 kΩ bottom gives 4.0. Use resistor values and power ratings appropriate to your maximum voltage.

## Project files

```text
EV_ADAS_STM32F103C8T6/
├── Core/
│   ├── Inc/
│   │   ├── adas.h
│   │   ├── app_config.h
│   │   └── ev_monitor.h
│   └── Src/
│       ├── adas.c
│       ├── ev_monitor.c
│       └── main_integration_example.c
├── Documentation/
│   └── pinout-and-test-plan.md
└── README.md
```

## Test plan

1. Power the Blue Pill from a regulated 3.3 V-compatible board supply.
2. Confirm the divider output never exceeds 3.3 V before connecting PA0.
3. Test ADC readings with a known safe low-voltage input.
4. Test the HC-SR04 with an object at a measured distance.
5. Verify the LED and buzzer output states.
6. Confirm UART output, if enabled.

## Limitations

- ADC voltage conversion assumes a 3.3 V reference; calibrate against a multimeter.
- HC-SR04 timing is a basic polling implementation and should be improved for robust production use.
- No battery current, temperature, state-of-charge, CAN, motor control, braking, or steering function is implemented in this starter.
- This package contains source modules and integration guidance, not a complete CubeIDE-generated project with startup files, linker script, `.ioc`, or HAL library.

## Author

**Hari Kota**  
B.Tech — Electronics and Communication Engineering, Parul University  
GitHub: https://github.com/harikota333-cmyk
