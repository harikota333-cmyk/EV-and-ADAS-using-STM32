#include "ev_monitor.h"
#include "app_config.h"

void EV_Monitor_Init(void)
{
    /* Reserved for future sensor initialization. */
}

EV_MonitorData_t EV_Monitor_Read(ADC_HandleTypeDef *hadc)
{
    EV_MonitorData_t result = {0};
    uint32_t raw = 0;

    if (hadc == NULL)
        return result;

    if (HAL_ADC_Start(hadc) == HAL_OK)
    {
        if (HAL_ADC_PollForConversion(hadc, 20) == HAL_OK)
            raw = HAL_ADC_GetValue(hadc);
        (void)HAL_ADC_Stop(hadc);
    }

    result.adc_pin_voltage =
        ((float)raw / ADC_MAX_COUNT) * ADC_REFERENCE_VOLTAGE;

    result.estimated_battery_voltage =
        result.adc_pin_voltage * BATTERY_DIVIDER_RATIO;

    result.low_voltage_warning =
        (result.estimated_battery_voltage < BATTERY_WARN_VOLTAGE) ? 1U : 0U;

    return result;
}
