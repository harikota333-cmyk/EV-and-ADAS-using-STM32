/*
 * INTEGRATION EXAMPLE — merge into your CubeMX-generated main.c.
 * Do not replace the generated SystemClock_Config(), MX_GPIO_Init(),
 * MX_ADC1_Init(), or HAL initialization with this snippet.
 *
 * Required generated handles:
 *   ADC_HandleTypeDef hadc1;
 *
 * Required CubeMX GPIO setup:
 *   PB0 output, PB1 input, PC13 output, PB12 output.
 *   ADC1 channel 0 on PA0.
 */

#include "main.h"
#include "ev_monitor.h"
#include "adas.h"
#include <stdio.h>

extern ADC_HandleTypeDef hadc1;

void App_RunOnce(void)
{
    EV_MonitorData_t ev = EV_Monitor_Read(&hadc1);
    ADAS_Data_t adas = ADAS_ReadDistance();

    ADAS_UpdateWarning(&adas);

    /* Set a breakpoint here to inspect:
       ev.estimated_battery_voltage
       ev.low_voltage_warning
       adas.distance_cm
       adas.obstacle_warning
    */
    (void)ev;
    HAL_Delay(100);
}

/* In the generated main() while(1) loop, call:
 *
 *   App_RunOnce();
 *
 */
