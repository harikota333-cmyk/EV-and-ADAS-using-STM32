#include "adas.h"
#include "app_config.h"

/* Example pin mapping: TRIG=PB0, ECHO=PB1, LED=PC13, buzzer=PB12.
   Ensure HC-SR04 ECHO is level-shifted to 3.3 V before PB1. */

static void delay_us_approx(uint32_t us)
{
    /* Approximate software delay; tune/replace with a hardware timer
       for accurate measurements. Assumes a 72 MHz system clock. */
    volatile uint32_t count = us * 8U;
    while (count--) { __NOP(); }
}

void ADAS_Init(void)
{
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);
    /* PC13 polarity varies by board; this example assumes active-low LED. */
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
}

ADAS_Data_t ADAS_ReadDistance(void)
{
    ADAS_Data_t data = {0};
    uint32_t elapsed = 0;

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
    delay_us_approx(2);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
    delay_us_approx(10);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);

    while (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == GPIO_PIN_RESET)
    {
        delay_us_approx(1);
        if (++elapsed >= ULTRASONIC_TIMEOUT_US)
            return data;
    }

    elapsed = 0;
    while (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == GPIO_PIN_SET)
    {
        delay_us_approx(1);
        if (++elapsed >= ULTRASONIC_TIMEOUT_US)
            return data;
    }

    /* Approximate HC-SR04 conversion: distance(cm) = echo_us / 58. */
    data.distance_cm = (float)elapsed / 58.0f;
    data.valid_reading = 1U;
    data.obstacle_warning =
        (data.distance_cm <= ADAS_WARN_DISTANCE_CM) ? 1U : 0U;

    return data;
}

void ADAS_UpdateWarning(const ADAS_Data_t *data)
{
    if ((data != NULL) && data->valid_reading && data->obstacle_warning)
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);
    }
    else
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);
    }
}
