#ifndef ADAS_H
#define ADAS_H

#include "stm32f1xx_hal.h"

typedef struct
{
    float distance_cm;
    uint8_t obstacle_warning;
    uint8_t valid_reading;
} ADAS_Data_t;

void ADAS_Init(void);
ADAS_Data_t ADAS_ReadDistance(void);
void ADAS_UpdateWarning(const ADAS_Data_t *data);

#endif
