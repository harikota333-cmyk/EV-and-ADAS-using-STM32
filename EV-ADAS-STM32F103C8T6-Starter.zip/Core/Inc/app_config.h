#ifndef APP_CONFIG_H
#define APP_CONFIG_H

/* Example configuration only. Calibrate for your actual hardware. */
#define ADC_REFERENCE_VOLTAGE       3.3f
#define ADC_MAX_COUNT               4095.0f

/* Example divider: R_TOP=30k, R_BOTTOM=10k => ratio 4.0 */
#define BATTERY_DIVIDER_RATIO       4.0f
#define BATTERY_WARN_VOLTAGE        10.5f

#define ADAS_WARN_DISTANCE_CM       30.0f
#define ULTRASONIC_TIMEOUT_US       30000U

#endif
