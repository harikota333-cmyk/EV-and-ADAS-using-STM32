#ifndef EV_MONITOR_H
#define EV_MONITOR_H

#include "stm32f1xx_hal.h"

typedef struct
{
    float adc_pin_voltage;
    float estimated_battery_voltage;
    uint8_t low_voltage_warning;
} EV_MonitorData_t;

void EV_Monitor_Init(void);
EV_MonitorData_t EV_Monitor_Read(ADC_HandleTypeDef *hadc);

#endif
