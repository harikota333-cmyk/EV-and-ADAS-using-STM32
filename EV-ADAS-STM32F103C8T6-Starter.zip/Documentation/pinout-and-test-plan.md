# Pinout and bench test plan

## Pinout

| Signal | Blue Pill pin | Notes |
|---|---|---|
| Battery divider output | PA0 / ADC1_IN0 | Must remain between 0 and 3.3 V |
| HC-SR04 TRIG | PB0 | 3.3 V GPIO output |
| HC-SR04 ECHO | PB1 | Level-shift 5 V ECHO to 3.3 V |
| Warning LED | PC13 | On-board LED polarity may be active-low |
| Buzzer driver | PB12 | Use transistor/MOSFET driver |

## Bench checks

- Verify wiring and common ground with power disconnected.
- Measure PA0 divider output before connecting the MCU.
- Do not connect automotive battery voltage directly to the board.
- Check sensor readings at known distances.
- Check buzzer driver current and polarity.
- Do not connect this demo to a real vehicle control system.
